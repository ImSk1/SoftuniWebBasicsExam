﻿namespace Library.Models
{
    public class BooksAllViewModel
    {
        public List<BookViewModel> Books { get; set; }
    }
}
